var app = angular.module("tuts",[]);

app.controller("employeeCtrl",[function(){

	this.employees = [
		{"name" : "abhilash","designation":"UI develoeper","experience" : 5},
		{"name" : "karam","designation":"UX designer","experience" : 2},
		{"name" : "hari","designation":"Java develoeper","experience" : 4},
		{"name" : "Adam","designation":"PHP develoeper","experience" : 10},
		{"name" : "Patrick","designation":"BA","experience" : 9.3},
		{"name" : "Andrew","designation":".NET develoeper","experience" : 3.4},
		{"name" : "Brad","designation":"Tester","experience" : 3},
	]
}]);