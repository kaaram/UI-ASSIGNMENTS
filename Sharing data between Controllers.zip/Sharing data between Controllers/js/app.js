var app = angular.module("tuts",[]);

app.service("users",function(){
	this.list = [
		{"name" : "John","emp_no":234,"exp":"10 Years"},
		{"name" : "Smith","emp_no":983,"exp":"5 Years"},
		{"name" : "Andrew","emp_no":892,"exp":"3 Years"}
	]
});

app.controller("UserCtrl",['users',function(users){
	console.log("inside use");
	this.userList = users.list;
}]);

app.controller("AdminCtrl",['users',function(users){
	this.user = {};

	this.add = function(){
		users.list.push(this.user);
		this.user ={};
	}
}]);