var app = angular.module("tuts",[]);

app.service("contacts",function(){
	var contacts = [
		{"id":31233123667,"name" : "abhilash","email":"abhi@gmail.com","number":3352627278}
	];

	
	this.getContacts = function(){
		return contacts;
	}

	this.deleteContact = function(contact){
		var index = contacts.indexOf(contact);
		contacts.splice(index,1);
	}

	this.updateContact = function(contact){		
		if(contact.id){
			for(var i=0;i<contacts.length;i++){
				if(contacts[i].id === contact.id){
					contacts[i].name = contact.name;
					contacts[i].email = contact.email;
					contacts[i].number = contact.number;
				}
			}
		} else {
			
			contact.id = new Date().getTime();
			contacts.push(contact);
		}
	}

	this.getInfo = function(name){
		var info = "";
		for(var i=0;i<contacts.length;i++){
			if(contacts[i].name.indexOf(name) >= 0){
				info = contacts[i];
				console.log(info);
				break;
			}
		}	
		return info;
	}
});

app.controller("PhoneBookAdminCtrl",['contacts',function(contacts){
	this.contact ={};
	this.contactList = contacts.getContacts();

	this.save = function(){
		if(this.contact.name && this.contact.number){
			contacts.updateContact(this.contact);
			this.contact ={};
		} else {
			alert("Please Enter All Mandatory Fields");
		}			
	}

	this.edit = function(contact){
		// to isolate the reference
		this.contact = angular.copy(contact);
	}

	this.delete = function(contact){
		contacts.deleteContact(contact);
	}

}]);

app.controller("PhoneBookUserCtrl",['contacts',function(contacts){
	this.get=function(name){
		this.userInfo = contacts.getInfo(name);
	}
}]);