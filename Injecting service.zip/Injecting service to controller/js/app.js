var app = angular.module("tuts",[]);

app.service("books",function(){
	var books = [
		{"name" : "AngularJS","version":"1.2.0","price":"$28"},
		{"name" : "backbone","version":"3.4.0","price":"$32"},
		{"name" : "ember","version":"4.8","price":"$21"}
	];

	this.addBook = function(book){
		books.push(book);
	}

	this.bookList = function () {
		return books;
	}
});

app.controller("UserCtrl",['books',function(books){
	this.book ={};
	this.booksObj = books.bookList();

	this.add = function(){
		books.addBook(this.book);
		this.book = {};
	}
}]);